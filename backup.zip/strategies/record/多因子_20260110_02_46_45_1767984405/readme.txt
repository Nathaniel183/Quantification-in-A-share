多因子
运行时间：20260110_02_46_45
数据：202012-202512
初始资金 10000000.00 最终资金 42271791.00
总收益 322.72% 年化收益 33.40% 最大回撤28.39%
描述：
            [factors.Size(),
            factors.Value(),
            factors.Turnover(),
            factors.Momentum(),
            factors.FScore()]