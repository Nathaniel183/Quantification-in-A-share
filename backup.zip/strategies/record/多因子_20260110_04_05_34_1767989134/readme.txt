多因子
运行时间：20260110_04_05_34
数据：202012-202512
初始资金 10000000.00 最终资金 15456032.00
总收益 54.56% 年化收益 9.09% 最大回撤42.06%
描述：
[
            factors.Size(),
            factors.Value(),
            factors.Turnover(),
            factors.Momentum(12,1),
            factors.FScore(),
            factors.MScore(),
            factors.Industry(),
    ]