多因子
运行时间：20260110_03_54_20
数据：202012-202512
初始资金 10000000.00 最终资金 16407301.00
总收益 64.07% 年化收益 10.40% 最大回撤35.15%
描述：
            [factors.Value(),
            factors.Turnover(),
            factors.Momentum(),
            factors.FScore()]