"""

"""
import pandas as pd
from strategies.strategy import Strategy
import data_api
from factors import Factor, get_factor

class StgDemo2(Strategy):
    def __init__(self, cash: float, datas: pd.DataFrame):
        """
        :param cash: 本金
        :param datas: 固定格式，DataFrame(index=(date, code), col=['open', 'close', 'high', 'low', 'volume'], open、close必备)
        """
        super().__init__(cash, datas, save=True)

        self.m_gate = -2.22 # -1.78
        self.strategy_name = "F-Score与换手率"

    def next(self):

        fscore = get_factor(Factor.FSCORE, self.date_cur)
        mscore = get_factor(Factor.MSCORE, self.date_cur)
        turnover = get_factor(Factor.TURNOVER, self.date_cur)

        # 计算双重排序
        ret = data_api.double_sort(fscore, turnover,
                                   'F-Score', Factor.TURNOVER.value,
                                   3, 5,
                                   ascend1=False, ascend2=True)

        # 根据 M 过滤
        # ret = ret.merge(mscore, how='left', on='股票代码')
        # ret = ret.loc[ret['M']==True]

        # 过程记录
        stock_info = data_api.get_stock_list(ret['股票代码'])[['股票代码','股票名称','所属行业']]
        stock_info = pd.merge(ret, stock_info, on='股票代码', how='left')

        # 选出目标组
        ret = ret.loc[(ret['group1']==3) & (ret['group2']==1)]

        # 清仓
        self.clear()

        # 计算购买数量
        counts = []
        for index, row in ret.iterrows():
            code = row['股票代码']
            c = self.count_compute(code, 0.05, 100)
            if c < 100:
                continue
            counts.append({'code': code, 'count': c})
            if len(counts) >= 20:
                break

        print(ret.loc[ret['股票代码'].isin([item['code'] for item in counts])])

        # 下单
        for item in counts:
            self.buy(item['code'], 0, item['count'], False)

        # 过程记录保存
        n = "10%"
        stock_info['仓位'] = stock_info['股票代码'].apply(
            lambda x: n if x in {item['code'] for item in counts} else '0'
        )
        #stock_info.to_csv(f'./detail1/{self.date_cur}.csv',index=False)





if __name__ == '__main__':
    strategy = StgDemo2(cash=10000000,
                        datas=data_api.get_monthly_qfq('20191201', '20260101'))
                        #datas=data_api.get_monthly_qfq('20240901', '20251201'))
    strategy.run()