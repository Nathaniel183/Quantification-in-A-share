"""
该软件包用于获取、计算、记录、更新因子和指标
在软件包内，使用 build 模块调用各指标计算方法，并记录计算结果CSV，同时在有新数据时更新
在软件包外，使用获取接口直接从记录的数据中获取
"""
import pandas as pd
from enum import Enum
import os

class Factor(Enum):
    FSCORE = "F-Score"
    MSCORE = "M-Score"
    MOMENTUM_12_1 = "momentum_n12_s1"
    MOMENTUM_6_0 = "momentum_n6_s0"
    MOMENTUM_3_0 = "momentum_n3_s0"
    MOMENTUM_1 = "momentum_n1"
    SIZE = "size"
    VALUE = "value"
    TURNOVER = "turnover"

def _factor_path(factor_name:str):
    """
    获取因子数据文件路径
    :param factor_name:因子名
    :return: 文件路径
    """
    current_file_path = os.path.dirname(os.path.abspath(__file__))
    return current_file_path+f"/factor_data/{factor_name}.csv"

def get_factor(factor:Factor, date:str=None):
    """
    获取因子数据（全部或指定日期）
    :param factor: 因子类型（Factor类枚举变量）
    :param date: 日期或月份，为 None 时返回全部数据
    :return: DataFrame(column=['股票代码', '因子名'])
    """

    datas = pd.read_csv(_factor_path(factor.value),dtype={'股票代码':str})
    if date is None:
        return datas.reset_index(drop=True)
    else:
        datas = datas[['股票代码',date]].reset_index(drop=True)
        datas = datas.rename(columns={date:factor.value})
        return datas

def get_change():
    """
    获取收益率（涨跌幅）
    目前只支持 月度后复权数据
    :return: DataFrame(index=(date, code), col=['change'])
    """
    datas = pd.read_csv("./../factor_data/change.csv", index_col=(0,1), dtype={'date':str, 'code':str})
    return datas

from .factor_builder.industry_dummy_variable import get_industry_dummies

__all__ = ['Factor', 'get_factor', 'get_change', 'get_industry_dummies']

# if __name__ == '__main__':
#     ret = get_factor(Factor.MOMENTUM, '202512')
#     print(ret)